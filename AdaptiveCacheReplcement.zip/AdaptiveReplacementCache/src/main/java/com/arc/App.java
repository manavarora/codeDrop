package com.arc;

import java.util.Scanner;

import com.arc.db.manager.DBManager;

/**
 * Hello world!
 *
 */
public class App {
	public static String PASSWORD = "1234";
	public static String USER = "postgres";
	public static String URL = "jdbc:postgresql://localhost:5432/TEST";
	public static Integer CacheSize = 0;

	public static void main(String[] args) throws Exception {
		String key, value;

		DBManager manager = new DBManager();

		Scanner scan = new Scanner(System.in);
		System.out.print("DB Url:");
		URL = scan.nextLine();

		System.out.println("DB Username:");
		USER = scan.nextLine();

		System.out.println("DB Password:");
		PASSWORD = scan.nextLine();

		System.out.println("Cache Size:");
		CacheSize = scan.nextInt();

		System.out.println("No. Of Entries:");
		int testcases = scan.nextInt();

		manager.connect(URL, USER, PASSWORD, CacheSize);

		while (testcases-- > 0) {
			System.out.println("Key:");
			
			key = scan.next();
			
			System.out.println("Value:");
			
			value = scan.next();
			
			manager.saveOrUpdate(key, value);

		}

		manager.disconnect();

	}
}
