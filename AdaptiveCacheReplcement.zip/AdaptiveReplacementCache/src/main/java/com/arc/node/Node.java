package com.arc.node;

public class Node{
	String key;
	String value;
	Node next = null;
	Node prev = null;
	
	public Node(String key,String value) {
		this.key = key;
		this.value = value;
	}

	public Node delink()
	{
		if(prev != null)
		{
			this.prev.next = this.next;
		}
		else
		{
			return this.next;
		}
		return null;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Node getNext() {
		return next;
	}

	public void setNext(Node next) {
		this.next = next;
	}

	public Node getPrev() {
		return prev;
	}

	public void setPrev(Node prev) {
		this.prev = prev;
	}
	
}