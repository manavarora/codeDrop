package com.arc.utils;

import java.util.ArrayList;
import java.util.HashMap;

import com.arc.node.Node;

public class Cache {

	private int maxSize;
	int marker;
	private HashMap<String, Node> t1Map;
	private HashMap<String, Node> t2Map;
	private HashMap<String, Node> d1Map;
	private HashMap<String, Node> d2Map;

	private Node t1Front = null;
	private Node t1Rear = null;
	private Node t2Front = null;
	private Node t2Rear = null;
	private Node d1Front = null;
	private Node d1Rear = null;
	private Node d2Front = null;
	private Node d2Rear = null;

	private int t1size = 0;
	private int d1size = 0;

	private int t2size = 0;
	private int d2size = 0;

	private ArrayList<Node> dataToSave = new ArrayList<Node>();

	public ArrayList<Node> getDataToSave() {

		return dataToSave;
	}

	public Cache(int size) {
		this.maxSize = size;
		this.marker = ((Double) Math.floor(size / 2)).intValue();
		this.t1Map = new HashMap<String, Node>();
		this.t2Map = new HashMap<String, Node>();
		this.d1Map = new HashMap<String, Node>();
		this.d2Map = new HashMap<String, Node>();

	}

	public Node add(String key, String value) {
		Node n = null;
		if (t1Map.containsKey(key)) {
			n = delinkT1Node(key);
			n.setValue(value);
			return saveToT2(n);
		} else if (d1Map.containsKey(key)) {
			n = delinkD1Node(key);
			n.setValue(value);
			incrementMarker();
			return saveToT2(n);
		} else if (t2Map.containsKey(key)) {
			n = delinkT2Node(key);
			n.setValue(value);
			return saveToT2(n);
		} else if (d2Map.containsKey(key)) {
			n = delinkD2Node(key);
			n.setValue(value);
			decrementMarker();
			return saveToT2(n);
		} else {

			n = new Node(key, value);
			return saveToT1(n);
		}

	}

	private void incrementMarker() {
		if (this.marker + 1 <= this.maxSize) {
			this.marker++;

			if (this.maxSize - this.marker < t2size) {
				if (evictFromT2()) {
					t2size--;
				}
			}
		}

	}

	private void decrementMarker() {
		if (this.marker - 1 >= 0) {
			this.marker--;

			if (this.marker < t1size) {
				if (evictFromT1()) {
					t1size--;
				}
			}
		}

	}

	private Node saveToT1(Node n) {
		if (n != null) {
			n.setNext(null);
			n.setPrev(null);
			t1Map.put(n.getKey(), n);
			if (t1Front != null) {
				n.setNext(t1Front);
				t1Front.setPrev(n);
				t1Front = n;
			} else if (t1Rear == null) {
				t1Rear = n;
			}
			t1Front = n;
			if (t1size + 1 > marker) {
				evictFromT1();
			} else {
				t1size++;
			}

		} else {
			System.err.println("Invalid Node");
		}
		return null;
	}

	private boolean evictFromT1() {
		if (t1Rear != null) {
			dataToSave.add(t1Rear);
			System.out.println("Saving ->Key:" + t1Rear.getKey() + " ;Value: " + t1Rear.getValue());

			Node n = t1Rear;
			t1Map.remove(t1Rear.getKey());
			if (t1Rear.getPrev() != null) {
				t1Rear = t1Rear.getPrev();
				t1Rear.setNext(null);
			}else
			{
				t1Rear = null;
				t1Front = null;
			}
			saveToD1(n);

			return true;
		}
		return false;
	}

	private void saveToD1(Node n) {
		if (n != null) {
			n.setNext(null);
			n.setPrev(null);
			d1Map.put(n.getKey(), n);
			if (d1Front != null) {
				n.setNext(d1Front);
				d1Front.setPrev(n);
				d1Front = n;

			} else if (d1Rear == null) {
				d1Rear = n;
			}
			d1Front = n;
			if (d1size + 1 > maxSize / 2) {
				evictFromD1();
			} else {
				d1size++;
			}

		} else {
			System.err.println("Invalid Node");
		}
	}

	private void evictFromD1() {
		if (d1Rear != null) {
			d1Map.remove(d1Rear.getKey());

			if (d1Rear.getPrev() != null) {
				d1Rear = d1Rear.getPrev();
				d1Rear.setNext(null);
			}else
			{
				d1Rear = null;
				d1Front = null;
			}
		}

	}

	private Node saveToT2(Node n) {
		if (n != null) {
			n.setNext(null);
			n.setPrev(null);
			t2Map.put(n.getKey(), n);
			if (t2Front != null) {
				n.setNext(t2Front);
				t2Front.setPrev(n);
				t2Front = n;

			} else if (t2Rear == null) {
				t2Rear = n;
			}
			t2Front = n;
			t2size++;
			while (t2size > maxSize - marker) {
				evictFromT2();
				t2size--;
			}

		} else {
			System.err.println("Invalid Node");
		}
		return null;
	}

	private boolean evictFromT2() {
		if (t2Rear != null) {
			dataToSave.add(t2Rear);
			System.out.println("Saving ->Key:" + t2Rear.getKey() + " ; Value: " + t2Rear.getValue());

			t2Map.remove(t2Rear.getKey());

			Node n = t2Rear;

			if (t2Rear.getPrev() != null) {
				t2Rear = t2Rear.getPrev();
				t2Rear.setNext(null);
			}else
			{
				t2Front = null;
				t2Rear = null;
			}
			saveToD2(n);

			return true;
		}
		return false;

	}

	private void saveToD2(Node n) {
		if (n != null) {
			n.setNext(null);
			n.setPrev(null);
			d2Map.put(n.getKey(), n);
			if (d2Front != null) {
				n.setNext(d2Front);
				d2Front.setPrev(n);
				d2Front = n;

			} else if (d2Rear == null) {
				d2Rear = n;
			}
			d2Front = n;
			d2size++;

			while (d2size > maxSize / 2) {
				evictFromD2();
				d2size--;
			}

		} else {
			System.err.println("Invalid Node");
		}
	}

	private void evictFromD2() {
		if (d2Rear != null) {
			d2Map.remove(d2Rear.getKey());

			if (d2Rear.getPrev() != null) {
				d2Rear = d2Rear.getPrev();
				d2Rear.setNext(null);
			}
		}

	}

	private Node delinkD2Node(String key) {

		Node n = d2Map.get(key);
		d2Map.remove(key);
		if (n != null) {

			if (n.getNext() != null) {
				if (n.getPrev() != null) {
					n.getPrev().setNext(n.getNext());
				} else {
					d2Front = null;
				}
			} else {
				if (n.getPrev() != null) {
					n.getPrev().setNext(null);
					d2Rear = n.getPrev();
				} else {
					d2Front = null;
					d2Rear = null;
				}
			}
			n.setNext(null);
			n.setPrev(null);
			d2size--;
			if (d2size < 0) {
				System.out.println("Something is wrong here");
			}
		} else {
			System.err.println("invalid Node");
		}

		return n;
	}

	private Node delinkT2Node(String key) {

		Node n = t2Map.get(key);
		t2Map.remove(key);
		if (n != null) {

			if (n.getNext() != null) {
				if (n.getPrev() != null) {
					n.getPrev().setNext(n.getNext());
				} else {
					t2Front = null;
				}
			} else {
				if (n.getPrev() != null) {
					n.getPrev().setNext(null);
					t2Rear = n.getPrev();
				} else {
					t2Front = null;
					t2Rear = null;
				}
			}
			n.setNext(null);
			n.setPrev(null);
			t2size--;
			if (t2size < 0) {
				System.out.println("Something is wrong here");
			}
		} else {
			System.err.println("invalid Node");
		}

		return n;
	}

	private Node delinkD1Node(String key) {

		Node n = d1Map.get(key);
		d1Map.remove(key);
		if (n != null) {

			if (n.getNext() != null) {
				if (n.getPrev() != null) {
					n.getPrev().setNext(n.getNext());
				} else {
					d1Front = null;
				}
			} else {
				if (n.getPrev() != null) {
					n.getPrev().setNext(null);
					d1Rear = n.getPrev();
				} else {
					d1Front = null;
					d1Rear = null;
				}
			}
			n.setNext(null);
			n.setPrev(null);
			if (d1size > 0) {
				d1size--;
			}

		} else {
			System.err.println("Invalid Node");
		}
		return n;
	}

	private Node delinkT1Node(String key) {

		Node n = t1Map.get(key);
		t1Map.remove(key);
		if (n != null) {

			if (n.getNext() != null) {
				if (n.getPrev() != null) {
					n.getPrev().setNext(n.getNext());
				} else {
					t1Front = null;
				}
			} else {
				if (n.getPrev() != null) {
					n.getPrev().setNext(null);
					t1Rear = n.getPrev();
				} else {
					t1Front = null;
					t1Rear = null;
				}
			}
			n.setNext(null);
			n.setPrev(null);
			if (t1size > 0) {
				t1size--;
			}
		} else {
			System.err.println("invalid NOde");
		}
		return n;
	}

	public void resetDataToSave() {
		this.dataToSave = new ArrayList<Node>();

	}

}
