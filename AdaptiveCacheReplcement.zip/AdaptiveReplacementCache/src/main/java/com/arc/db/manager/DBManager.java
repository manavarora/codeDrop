package com.arc.db.manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.arc.node.Node;
import com.arc.utils.Cache;

public class DBManager {

	Connection connection = null;

	Cache cache = null;

	public void connect(String url, String user, String password, int cacheSize) throws Exception {

		if (url != null && user != null && password != null && cacheSize > 0) {
			connection = DriverManager.getConnection(url, user, password);
			cache = new Cache(cacheSize);

		} else {
			throw new Exception("DBManager->connect:Invalid Parameters");
		}
	}

	public void saveOrUpdate(String key, String value) throws SQLException {

		cache.add(key, value);
		if (cache.getDataToSave() != null && cache.getDataToSave().size() > 0) {
			Statement statement = connection.createStatement();

			for (Node n : cache.getDataToSave()) {
				String sKey = n.getKey();
				String sValue = n.getValue();
				System.out.println(sKey+":"+sValue);
				statement.execute("INSERT INTO public.dataset(key, value)	VALUES ('" + sKey + "','" + sValue + "')"
						+ "ON CONFLICT (key) DO UPDATE  SET value = '" + sValue + "' ;");
			}
			statement.close();

			cache.resetDataToSave();

		}

	}

	public void disconnect() throws SQLException {
		if (connection != null) {
			connection.close();
		}

	}
}
